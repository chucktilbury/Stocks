---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

*** READ BEFORE POSTING ***

Before posting an issue - please upgrade to the latest version and confirm the issue/bug is still there.

Upgrade using:
`$ pip install yfinance --upgrade --no-cache-dir`

Bug still there? Delete this content and submit your bug report here and provide the following, as best you can:

- Simple code that reproduces your problem
- The error message
