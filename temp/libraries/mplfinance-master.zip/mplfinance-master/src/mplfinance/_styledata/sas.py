# style sas is just an abbreviation for starsandstripes:

from mplfinance._styledata import starsandstripes
style = starsandstripes.style
