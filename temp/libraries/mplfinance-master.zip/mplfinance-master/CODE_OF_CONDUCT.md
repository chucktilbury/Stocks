
#### All typical collaboration codes of conduct apply:

### Treat people fairly, with respect, and overall [be a mensch](https://www.google.com/search?q=mensch).
