Examples
========

.. plot:: ../../examples/date_demo1.py
   :include-source:

.. plot:: ../../examples/date_demo2.py
   :include-source:

.. plot:: ../../examples/finance_demo.py
   :include-source:

.. plot:: ../../examples/finance_work2.py
   :include-source:

.. plot:: ../../examples/longshort.py
   :include-source:

.. plot:: ../../examples/plot_day_summary_oclh_demo.py
   :include-source:
