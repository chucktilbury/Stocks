"""
written and developed by Daniel Temkin
please refer to LICENSE for ownership and reference information
"""
