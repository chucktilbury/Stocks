Federal Reserve Economic Data (FRED)
------------------------------------

.. py:module:: pandas_datareader.fred

.. autoclass:: FredReader
   :members:
   :inherited-members: read


