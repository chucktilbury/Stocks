Tiingo
------

.. py:module:: pandas_datareader.tiingo

.. autoclass:: TiingoDailyReader
   :members:
   :inherited-members:

.. autoclass:: TiingoQuoteReader
   :members:
   :inherited-members:

.. autoclass:: TiingoMetaDataReader
   :members:
   :inherited-members:

.. autofunction:: get_tiingo_symbols
