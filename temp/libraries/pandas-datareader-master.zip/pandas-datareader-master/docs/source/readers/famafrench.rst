Fama-French Data (Ken French's Data Library)
--------------------------------------------

.. py:module:: pandas_datareader.famafrench

.. autoclass:: FamaFrenchReader
   :members:
   :inherited-members:

.. autofunction:: get_available_datasets