World Bank
----------

.. py:module:: pandas_datareader.wb

.. autoclass:: WorldBankReader
   :members:
   :inherited-members:

.. autofunction:: download

.. autofunction:: get_countries

.. autofunction:: get_indicators

.. autofunction:: search
