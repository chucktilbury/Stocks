3D plot pan and zoom buttons
----------------------------

The pan and zoom buttons in the toolbar of 3D plots are now enabled.
Unselect both to rotate the plot. When the zoom button is pressed,
zoom in by using the left mouse button to draw a bounding box, and
out by using the right mouse button to draw the box. When zooming a
3D plot, the current view aspect ratios are kept fixed.
