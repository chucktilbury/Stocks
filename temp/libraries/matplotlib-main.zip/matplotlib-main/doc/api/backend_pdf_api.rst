:mod:`.backend_pdf`
===================

.. automodule:: matplotlib.backends.backend_pdf
   :members:
   :undoc-members:
   :show-inheritance:
