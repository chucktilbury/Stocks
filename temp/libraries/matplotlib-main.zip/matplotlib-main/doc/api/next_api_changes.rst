
================
Next API changes
================

.. ifconfig:: releaselevel == 'dev'

   .. toctree::
      :glob:
      :maxdepth: 1

      next_api_changes/behavior/*
      next_api_changes/deprecations/*
      next_api_changes/development/*
      next_api_changes/removals/*
