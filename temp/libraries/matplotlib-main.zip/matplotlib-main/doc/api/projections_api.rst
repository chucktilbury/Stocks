**************************
``matplotlib.projections``
**************************

.. automodule:: matplotlib.projections
   :members:
   :show-inheritance:

``matplotlib.projections.polar``
================================

.. automodule:: matplotlib.projections.polar
   :members:
   :show-inheritance:

``matplotlib.projections.geo``
==============================

.. automodule:: matplotlib.projections.geo
   :members:
   :show-inheritance:
