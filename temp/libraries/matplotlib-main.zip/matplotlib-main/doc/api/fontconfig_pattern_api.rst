*********************************
``matplotlib.fontconfig_pattern``
*********************************

.. automodule:: matplotlib.fontconfig_pattern
   :members:
   :undoc-members:
   :show-inheritance:
