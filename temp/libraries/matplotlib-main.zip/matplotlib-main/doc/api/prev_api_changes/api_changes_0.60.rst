Changes for 0.60
================

.. code-block:: text

  ColormapJet and Grayscale are deprecated.  For backwards
  compatibility, they can be obtained either by doing

    from matplotlib.cm import ColormapJet

  or

    from matplotlib.matlab import *

  They are replaced by cm.jet and cm.grey
