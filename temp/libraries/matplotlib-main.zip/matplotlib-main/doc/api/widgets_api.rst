**********************
``matplotlib.widgets``
**********************

.. inheritance-diagram:: matplotlib.widgets
   :parts: 1


.. automodule:: matplotlib.widgets
   :members:
   :undoc-members:
   :show-inheritance:
