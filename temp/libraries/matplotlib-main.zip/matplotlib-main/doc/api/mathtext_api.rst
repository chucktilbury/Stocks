***********************
``matplotlib.mathtext``
***********************

.. inheritance-diagram:: matplotlib.mathtext
   :parts: 1

.. automodule:: matplotlib.mathtext
   :members:
   :undoc-members:
   :show-inheritance:
